﻿using DSharpPlus.CommandsNext;
using DSharpPlus.CommandsNext.Attributes;
using DSharpPlus.Entities;
using DSharpPlus.Interactivity.Extensions;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;


namespace OOP_Bot.Commands
{
    class Command1 : BaseCommandModule//Command1 is a user defined class which is inherited by a pre defined class.
    {
        [Command("Ping")]//Command lets you name the command as you wish
        [Description("Prints Pong")]//Tells what the command do
        public async Task PingPong(CommandContext CC) //Method to store command in a function.     
        {
            await CC.Channel.SendMessageAsync("Pong").ConfigureAwait(false);//Reply to the server if this function is invoked 
        }


        [Command("Add")]//Command lets you name the command as you wish
        [Description("Adds two numbers")]//Tells what the command do
        public async Task Add(CommandContext CC, [Description("First Number")] float a, [Description("Second Number")] float b)//Method to store command in a function. In this case 2 parameters are passed.
        {
            await CC.Channel
                .SendMessageAsync("The sum is " + (a + b) + ".".ToString())//This performs addition task and convert it into string.
                .ConfigureAwait(false);
        }


        [Command("Subtract")]//Command lets you name the command as you wish
        [Description("Subtracts two numbers")]//Tells what the command do
        public async Task Subtract(CommandContext CC, [Description("First Number")] float a, [Description("Second Number")] float b)//Method to store command in a function. In this case 2 parameters are passed.
        {
            await CC.Channel
                .SendMessageAsync("The differance is " + (a - b) + ".".ToString())//This performs subtraction task and convert it into string.
                .ConfigureAwait(false);
        }


        [Command("Multiply")]//Command lets you name the command as you wish
        [Description("Multiplys two numbers")]//Tells what the command do
        public async Task Multiply(CommandContext CC, [Description("First Number")] float a, [Description("Second Number")] float b)//Method to store command in a function. In this case 2 parameters are passed.
        {
            await CC.Channel
                .SendMessageAsync("The product is " + (a * b) + ".".ToString())//This performs Multiplication task and convert it into string.
                .ConfigureAwait(false);
        }


        [Command("Divide")]//Command lets you name the command as you wish
        [Description("Gives the quotient after dividing two numbers")]//Tells what the command do
        public async Task Divide(CommandContext CC, [Description("First Number")] float a, [Description("Second Number")] float b)//Method to store command in a function. In this case 2 parameters are passed.
        {
            await CC.Channel
                .SendMessageAsync("The quotient is " + (a / b) + ".".ToString())//This performs Division task and convert it into string.
                .ConfigureAwait(false);
        }


        [Command("Remainder")]//Command lets you name the command as you wish
        [Description("Gives the remainder after dividing two numbers")]//Tells what the command do
        public async Task Remainder(CommandContext CC, [Description("First Number")] float a, [Description("Second Number")] float b)//Method to store command in a function. In this case 2 parameters are passed.
        {
            await CC.Channel
                .SendMessageAsync("The remainder is " + (a % b) + ".".ToString())//This performs Division task for remainder and convert it into string.
                .ConfigureAwait(false);
        }


        [Command("Sin")]//Command lets you name the command as you wish
        [Description("Calculates sine theeta")]//Tells what the command do
        public async Task Sin(CommandContext CC, [Description("Theeta")] double a)//Method to store command in a function. In this case 1 parameters are passed.
        {
            await CC.Channel
                .SendMessageAsync("Sin("+a+") is " + (Math.Sin(a) + ".").ToString())//This calculates sin of theeta that can be in degrees or radians and convert it into string.
                .ConfigureAwait(false);
        }


        [Command("Arcsin")]//Command lets you name the command as you wish
        [Description("Calculates inverse sine theeta")]//Tells what the command do
        public async Task ASin(CommandContext CC, [Description("Theeta")] double a)//Method to store command in a function. In this case 1 parameters are passed.
        {
            await CC.Channel
                .SendMessageAsync("Arcsin(" + a + ") is "+(Math.Asin(a) + " radians.").ToString())//This calculates arc sin of theeta and gives the result in radians and convert it into string.
                .ConfigureAwait(false);
        }


        [Command("Cos")]//Command lets you name the command as you wish
        [Description("Calculates Cosine theeta")]//Tells what the command do
        public async Task Cos(CommandContext CC, [Description("Theeta")] double a)//Method to store command in a function. In this case 1 parameters are passed.
        {
            await CC.Channel
                .SendMessageAsync("Cos(" + a + ") is " + (Math.Cos(a)+".").ToString())//This calculates Cos of theeta that can be in degrees or radians and convert it into string.
                .ConfigureAwait(false);
        }


        [Command("Arccos")]//Command lets you name the command as you wish
        [Description("Calculates inverse Cosine theeta")]//Tells what the command do
        public async Task ACos(CommandContext CC, [Description("Theeta")] double a)//Method to store command in a function. In this case 1 parameters are passed.
        {
            await CC.Channel
                .SendMessageAsync("Arccos(" + a + ") is " + (Math.Acos(a) + " radians.").ToString())//This calculates arc Cos of theeta and gives the result in radians and convert it into string.
                .ConfigureAwait(false);
        }


        [Command("Tan")]//Command lets you name the command as you wish
        [Description("Calculates tan theeta")]//Tells what the command do
        public async Task Tan(CommandContext CC, [Description("Theeta")] double a)//Method to store command in a function. In this case 1 parameters are passed.
        {
            await CC.Channel
                .SendMessageAsync("Tan(" + a + ") is " + (Math.Tan(a) + ".").ToString())//This calculates tan of theeta that can be in degrees or radians and convert it into string.
                .ConfigureAwait(false);
        }


        [Command("Arctan")]//Command lets you name the command as you wish
        [Description("Calculates inverse tan theeta")]//Tells what the command do
        public async Task ATan(CommandContext CC, [Description("Theeta")] double a)//Method to store command in a function. In this case 1 parameters are passed.
        {
            await CC.Channel
                .SendMessageAsync("Arctan(" + a + ") is " + (Math.Atan(a) + " radians.").ToString())//This calculates arc tan of theeta and gives the result in radians and convert it into string.
                .ConfigureAwait(false);
        }


        [Command("Power")]//Command lets you name the command as you wish
        [Description("Calculates power of a number")]//Tells what the command do
        public async Task Power(CommandContext CC, [Description("Base")] float a, [Description("Power")] int b)//Method to store command in a function. In this case 2 parameters are passed.
        {
            await CC.Channel
                .SendMessageAsync("Power " + b + " of " + a +" is " + (Math.Pow(a, b) + ".").ToString())//This calculates power of a number and convert it into string.
                .ConfigureAwait(false);
        }


        [Command("Square_root")]//Command lets you name the command as you wish
        [Description("Calculates square root of a number")]//Tells what the command do
        public async Task Sqrt(CommandContext CC, [Description("Number")] float a)//Method to store command in a function. In this case 1 parameters are passed.
        {
            await CC.Channel
                .SendMessageAsync("Square root of " + a + " is " + (Math.Sqrt(a) + ".").ToString())//This calculates square root of a number and convert it into string.
                .ConfigureAwait(false);
        }


        [Command("Log")]//Command lets you name the command as you wish
        [Description("Calculates natural log of a number")]//Tells what the command do
        public async Task Log(CommandContext CC, [Description("Number")] float a)//Method to store command in a function. In this case 1 parameters are passed.
        {
            await CC.Channel
                .SendMessageAsync("Log of " + a + "to base e i.e natural log is " + (Math.Log(a) + ".").ToString())//This calculates natural log of a number and convert it into string.
                .ConfigureAwait(false);
        }


        [Command("Log10")]//Command lets you name the command as you wish
        [Description("Calculates log to base 10 of a number")]//Tells what the command do
        public async Task Log10(CommandContext CC, [Description("Number")] float a)//Method to store command in a function. In this case 1 parameters are passed.
        {
            await CC.Channel
                .SendMessageAsync("Log of " + a + "to base 10 is " + (Math.Log10(a) + ".").ToString())//This calculates log to base 10 of a number and convert it into string.
                .ConfigureAwait(false);
        }


        [Command("Truncate")]//Command lets you name the command as you wish
        [Description("Cuts of decimal part of a number")]//Tells what the command do
        public async Task Truncate(CommandContext CC, [Description("Number")] float a)//Method to store command in a function. In this case 1 parameters are passed.
        {
            await CC.Channel
                .SendMessageAsync("Truncate of " + a + " is " + (Math.Truncate(a) + ".").ToString())//This Cuts of decimal part of a number and convert it into string.
                .ConfigureAwait(false);
        }


        [Command("Ceil")]//Command lets you name the command as you wish
        [Description("Returns the smallest integral value greater than or equal to the specified number")]//Tells what the command do
        public async Task Ceil(CommandContext CC, [Description("Number")] float a)//Method to store command in a function. In this case 1 parameters are passed.
        {
            await CC.Channel
                .SendMessageAsync("Ceil (" + a + ") is " + (Math.Ceiling(a) + ".").ToString())//This returns the smallest integral value greater than or equal to the specified number and convert it into string.
                .ConfigureAwait(false);
        }


        [Command("Floor")]//Command lets you name the command as you wish
        [Description("Returns the largest integral value less than or equal to the specified number.")]//Tells what the command do
        public async Task Floor(CommandContext CC, [Description("Number")] float a)//Method to store command in a function. In this case 1 parameters are passed.
        {
            await CC.Channel
                .SendMessageAsync("Floor (" + a + ") is " + (Math.Floor(a) + ".").ToString())//This returns the largest integral value less than or equal to the specified number and convert it into string.
                .ConfigureAwait(false);
        }


            [Command("Exponent")]//Command lets you name the command as you wish
        [Description("Returns e raised to the specified power.")]//Tells what the command do
        public async Task Exponent(CommandContext CC, [Description("Power")] float a)//Method to store command in a function. In this case 1 parameters are passed.
        {
            await CC.Channel
                .SendMessageAsync("e power " + a + " is " + (Math.Exp(a) + ".").ToString())//This returns e raised to the specified power and convert it into string.
                .ConfigureAwait(false);
        }


        [Command("BMI")]//Command lets you name the command as you wish
        [Description("Calculates BMI by taking weight in kilometers and height in meters.")]//Tells what the command do
        public async Task BMI(CommandContext CC, [Description("Weight")] float w, [Description("Height")] float h)//Method to store command in a function. In this case 2 parameters are passed.
        {
            if (w / (h * h) < 18.5)
            {
                await CC.Channel
             .SendMessageAsync("Your BMI is " + w / (h * h) + " and BMI category is Underweight.".ToString())//This calculates BMI and convert it into string.
             .ConfigureAwait(false);
            }
            else if (w / (h * h) >= 18.5 && w / (h * h) <= 24.9)
            {
                await CC.Channel
             .SendMessageAsync("Your BMI is " + w / (h * h) + " and BMI category is Normal.".ToString())//This calculates BMI and convert it into string.
             .ConfigureAwait(false);
            }
            else if (w / (h * h) >= 25 && w / (h * h) <= 29.9)
            {
                await CC.Channel
             .SendMessageAsync("Your BMI is " + w / (h * h) + " and BMI category is Overweight.".ToString())//This calculates BMI and convert it into string
             .ConfigureAwait(false);
            }
            else if (w / (h * h) >= 30)
            {
                await CC.Channel
             .SendMessageAsync("Your BMI is " + w / (h * h) + " and BMI category is Obese.".ToString())//This calculates BMI and convert it into string.
             .ConfigureAwait(false);
            }
        }


        [Command("Convert-In-Cm")]//Command lets you name the command as you wish
        [Description("Converts inch to centimeters")]//Tells what the command do
        public async Task In_to_Cm(CommandContext CC, [Description("Unit")] float a)//Method to store command in a function. In this case 1 parameters are passed.
        {
            await CC.Channel
                .SendMessageAsync(a+" inch is equal to "+(a*2.54)+ " centimeters.".ToString())//This converts inch and gives the result in centimeters and convert it into string.
                .ConfigureAwait(false);
        }


        [Command("Convert-In-M")]//Command lets you name the command as you wish
        [Description("Converts inch to meters")]//Tells what the command do
        public async Task In_to_M(CommandContext CC, [Description("Unit")] float a)//Method to store command in a function. In this case 1 parameters are passed.
        {
            await CC.Channel
                .SendMessageAsync(a + " inch is equal to " + (a / 39.37) + " meters.".ToString())//This converts inch and gives the result in meters and convert it into string.
                .ConfigureAwait(false);
        }


        [Command("Convert-In-Ft")]//Command lets you name the command as you wish
        [Description("Converts inch to feets")]//Tells what the command do
        public async Task In_to_Ft(CommandContext CC, [Description("Unit")] float a)//Method to store command in a function. In this case 1 parameters are passed.
        {
            await CC.Channel
                .SendMessageAsync(a + " inch is equal to " + (a / 12) + " feets.".ToString())//This converts inch and gives the result in feets and convert it into string.
                .ConfigureAwait(false);
        }


        [Command("Convert-In-Yd")]//Command lets you name the command as you wish
        [Description("Converts inch to yards")]//Tells what the command do
        public async Task In_to_Yd(CommandContext CC, [Description("Unit")] float a)//Method to store command in a function. In this case 1 parameters are passed.
        {
            await CC.Channel
                .SendMessageAsync(a + " inch is equal to " + (a / 36) + " yards.".ToString())//This converts inch and gives the result in yards and convert it into string.
                .ConfigureAwait(false);
        }


        [Command("Convert-Cm-M")]//Command lets you name the command as you wish
        [Description("Converts Centimeters to meters")]//Tells what the command do
        public async Task Cm_to_M(CommandContext CC, [Description("Unit")] float a)//Method to store command in a function. In this case 1 parameters are passed.
        {
            await CC.Channel
                .SendMessageAsync(a + " centimeter is equal to " + (a / 100) + " meters.".ToString())//This converts centimeters and gives the result in meters and convert it into string.
                .ConfigureAwait(false);
        }


        [Command("Convert-Cm-In")]//Command lets you name the command as you wish
        [Description("Converts Centimeters to Inches")]//Tells what the command do
        public async Task Cm_to_In(CommandContext CC, [Description("Unit")] float a)//Method to store command in a function. In this case 1 parameters are passed.
        {
            await CC.Channel
                .SendMessageAsync(a + " centimeter is equal to " + (a / 2.54) + " inches.".ToString())//This converts centimeters and gives the result in inches and convert it into string.
                .ConfigureAwait(false);
        }


        [Command("Convert-Cm-Ft")]//Command lets you name the command as you wish
        [Description("Converts Centimeters to Feets")]//Tells what the command do
        public async Task Cm_to_Ft(CommandContext CC, [Description("Unit")] float a)//Method to store command in a function. In this case 1 parameters are passed.
        {
            await CC.Channel
                .SendMessageAsync(a + " centimeter is equal to " + (a / 30.48) + " feets.".ToString())//This converts centimeters and gives the result in feets and convert it into string.
                .ConfigureAwait(false);
        }


        [Command("Convert-Cm-Yd")]//Command lets you name the command as you wish
        [Description("Converts Centimeters to yards")]//Tells what the command do
        public async Task Cm_to_Yd(CommandContext CC, [Description("Unit")] float a)//Method to store command in a function. In this case 1 parameters are passed.
        {
            await CC.Channel
                .SendMessageAsync(a + " centimeter is equal to " + (a / 91.44) + " yards.".ToString())//This converts centimeters and gives the result in yards and convert it into string.
                .ConfigureAwait(false);
        }


        [Command("Convert-M-Cm")]//Command lets you name the command as you wish
        [Description("Converts Meters to Centimeters")]//Tells what the command do
        public async Task M_to_Cm(CommandContext CC, [Description("Unit")] float a)//Method to store command in a function. In this case 1 parameters are passed.
        {
            await CC.Channel
                .SendMessageAsync(a + " meter is equal to " + (a * 100) + " centimeters.".ToString())//This converts meters and gives the result in centimeters and convert it into string.
                .ConfigureAwait(false);
        }


        [Command("Convert-M-In")]//Command lets you name the command as you wish
        [Description("Converts Meters to Inches")]//Tells what the command do
        public async Task M_to_In(CommandContext CC, [Description("Unit")] float a)//Method to store command in a function. In this case 1 parameters are passed.
        {
            await CC.Channel
                .SendMessageAsync(a + " meter is equal to " + (a * 39.37) + " inches.".ToString())//This converts meters and gives the result in inches and convert it into string.
                .ConfigureAwait(false);
        }


        [Command("Convert-M-Ft")]//Command lets you name the command as you wish
        [Description("Converts Meters to Feets")]//Tells what the command do
        public async Task M_to_Ft(CommandContext CC, [Description("Unit")] float a)//Method to store command in a function. In this case 1 parameters are passed.
        {
            await CC.Channel
                .SendMessageAsync(a + " meter is equal to " + (a * 3.281) + " feets.".ToString())//This converts meters and gives the result in feets and convert it into string.
                .ConfigureAwait(false);
        }


        [Command("Convert-M-Yd")]//Command lets you name the command as you wish
        [Description("Converts Meters to Yards")]//Tells what the command do
        public async Task M_to_Yd(CommandContext CC, [Description("Unit")] float a)//Method to store command in a function. In this case 1 parameters are passed.
        {
            await CC.Channel
                .SendMessageAsync(a + " meter is equal to " + (a * 1.094) + " Yards.".ToString())//This converts meters and gives the result in yards and convert it into string.
                .ConfigureAwait(false);
        }


        [Command("Convert-Yd-Cm")]//Command lets you name the command as you wish
        [Description("Converts Yards to Centimeters")]//Tells what the command do
        public async Task Yd_to_Cm(CommandContext CC, [Description("Unit")] float a)//Method to store command in a function. In this case 1 parameters are passed.
        {
            await CC.Channel
                .SendMessageAsync(a + " yard is equal to " + (a * 91.44) + " centimeters.".ToString())//This converts yards and gives the result in centimeters and convert it into string.
                .ConfigureAwait(false);
        }


        [Command("Convert-Yd-M")]//Command lets you name the command as you wish
        [Description("Converts Yards to Meters")]//Tells what the command do
        public async Task Yd_to_M(CommandContext CC, [Description("Unit")] float a)//Method to store command in a function. In this case 1 parameters are passed.
        {
            await CC.Channel
                .SendMessageAsync(a + " yard is equal to " + (a / 1.094) + " meters.".ToString())//This converts yards and gives the result in meters and convert it into string.
                .ConfigureAwait(false);
        }


        [Command("Convert-Yd-Ft")]//Command lets you name the command as you wish
        [Description("Converts Yards to Feets")]//Tells what the command do
        public async Task Yd_to_Ft(CommandContext CC, [Description("Unit")] float a)//Method to store command in a function. In this case 1 parameters are passed.
        {
            await CC.Channel
                .SendMessageAsync(a + " yard is equal to " + (a *3 ) + " feets.".ToString())//This converts yards and gives the result in feets and convert it into string.
                .ConfigureAwait(false);
        }


        [Command("Convert-Yd-In")]//Command lets you name the command as you wish
        [Description("Converts Yards to Inches")]//Tells what the command do
        public async Task Yd_to_In(CommandContext CC, [Description("Unit")] float a)//Method to store command in a function. In this case 1 parameters are passed.
        {
            await CC.Channel
                .SendMessageAsync(a + " yard is equal to " + (a * 36) + " inches.".ToString())//This converts yards and gives the result in inches and convert it into string.
                .ConfigureAwait(false);
        }


        [Command("Convert-Ft-Yd")]//Command lets you name the command as you wish
        [Description("Converts Feets to Yards")]//Tells what the command do
        public async Task Ft_to_Yd(CommandContext CC, [Description("Unit")] float a)//Method to store command in a function. In this case 1 parameters are passed.
        {
            await CC.Channel
                .SendMessageAsync(a + " feet is equal to " + (a / 3) + " yards.".ToString())//This converts feets and gives the result in yards and convert it into string.
                .ConfigureAwait(false);
        }


        [Command("Convert-Ft-In")]//Command lets you name the command as you wish
        [Description("Converts Feets to Inches")]//Tells what the command do
        public async Task Ft_to_In(CommandContext CC, [Description("Unit")] float a)//Method to store command in a function. In this case 1 parameters are passed.
        {
            await CC.Channel
                .SendMessageAsync(a + " feet is equal to " + (a * 12) + " inches.".ToString())//This converts feets and gives the result in inches and convert it into string.
                .ConfigureAwait(false);
        }


        [Command("Convert-Ft-Cm")]//Command lets you name the command as you wish
        [Description("Converts Feets to Centimeters")]//Tells what the command do
        public async Task Ft_to_Cm(CommandContext CC, [Description("Unit")] float a)//Method to store command in a function. In this case 1 parameters are passed.
        {
            await CC.Channel
                .SendMessageAsync(a + " feet is equal to " + (a * 30.48) + " centimeters.".ToString())//This converts feets and gives the result in centimeters and convert it into string.
                .ConfigureAwait(false);
        }


        [Command("Convert-Ft-M")]//Command lets you name the command as you wish
        [Description("Converts Feets to Meters")]//Tells what the command do
        public async Task Ft_to_M(CommandContext CC, [Description("Unit")] float a)//Method to store command in a function. In this case 1 parameters are passed.
        {
            await CC.Channel
                .SendMessageAsync(a + " feet is equal to " + (a / 3.281) + " meters.".ToString())//This converts feets and gives the result in meters and convert it into string.
                .ConfigureAwait(false);
        }


        [Command("Convert-Lb-G")]//Command lets you name the command as you wish
        [Description("Converts Pounds to Grams")]//Tells what the command do
        public async Task Lb_to_G(CommandContext CC, [Description("Unit")] float a)//Method to store command in a function. In this case 1 parameters are passed.
        {
            await CC.Channel
                .SendMessageAsync(a + " pound is equal to " + (a * 454) + " grams.".ToString())//This converts pounds and gives the result in grams and convert it into string.
                .ConfigureAwait(false);
        }


        [Command("Convert-Lb-Kg")]//Command lets you name the command as you wish
        [Description("Converts Pounds to Kilograms")]//Tells what the command do
        public async Task Lb_to_Kg(CommandContext CC, [Description("Unit")] float a)//Method to store command in a function. In this case 1 parameters are passed.
        {
            await CC.Channel
                .SendMessageAsync(a + " pound is equal to " + (a / 2.205) + " kilograms.".ToString())//This converts pounds and gives the result in kilograms and convert it into string.
                .ConfigureAwait(false);
        }


        [Command("Convert-G-Lb")]//Command lets you name the command as you wish
        [Description("Converts Grams to Pounds")]//Tells what the command do
        public async Task G_to_Lb(CommandContext CC, [Description("Unit")] float a)//Method to store command in a function. In this case 1 parameters are passed.
        {
            await CC.Channel
                .SendMessageAsync(a + " gram is equal to " + (a / 454) + " pounds.".ToString())//This converts grams and gives the result in pounds and convert it into string.
                .ConfigureAwait(false);
        }


        [Command("Convert-G-kg")]//Command lets you name the command as you wish
        [Description("Converts Grams to Kilograms")]//Tells what the command do
        public async Task G_to_Kg(CommandContext CC, [Description("Unit")] float a)//Method to store command in a function. In this case 1 parameters are passed.
        {
            await CC.Channel
                .SendMessageAsync(a + " gram is equal to " + (a / 1000) + " kilograms.".ToString())//This converts grams and gives the result in kilograms and convert it into string.
                .ConfigureAwait(false);
        }


        [Command("Convert-Kg-Lb")]//Command lets you name the command as you wish
        [Description("Converts Kilograms to Pounds")]//Tells what the command do
        public async Task Kg_to_Lb(CommandContext CC, [Description("Unit")] float a)//Method to store command in a function. In this case 1 parameters are passed.
        {
            await CC.Channel
                .SendMessageAsync(a + " kilogram is equal to " + (a * 2.205) + " pounds.".ToString())//This converts kilograms and gives the result in pounds and convert it into string.
                .ConfigureAwait(false);
        }


        [Command("Convert-Kg-G")]//Command lets you name the command as you wish
        [Description("Converts Kilograms to Grams")]//Tells what the command do
        public async Task Kg_to_G(CommandContext CC, [Description("Unit")] float a)//Method to store command in a function. In this case 1 parameters are passed.
        {
            await CC.Channel
                .SendMessageAsync(a + " kilogram is equal to " + (a * 1000) + " grams.".ToString())//This converts kilograms and gives the result in grams and convert it into string.
                .ConfigureAwait(false);
        }


        [Command("Convert-C-F")]//Command lets you name the command as you wish
        [Description("Converts Celsius to Fahrenheits")]//Tells what the command do
        public async Task C_to_F(CommandContext CC, [Description("Unit")] float a)//Method to store command in a function. In this case 1 parameters are passed.
        {
            await CC.Channel
                .SendMessageAsync(a + " celsius is equal to " + ((a * 9 / 5) + 32) + " fahrenheits.".ToString())//This converts celsius and gives the result in fahrenheits and convert it into string.
                .ConfigureAwait(false);
        }


        [Command("Convert-C-K")]//Command lets you name the command as you wish
        [Description("Converts Celsius to Kelvins")]//Tells what the command do
        public async Task C_to_K(CommandContext CC, [Description("Unit")] float a)//Method to store command in a function. In this case 1 parameters are passed.
        {
            await CC.Channel
                .SendMessageAsync(a + " celsius is equal to " + (a + 273.15) + " kelvins.".ToString())//This converts celsius and gives the result in kelvin and convert it into string.
                .ConfigureAwait(false);
        }


        [Command("Convert-F-C")]//Command lets you name the command as you wish
        [Description("Converts Fahrenheit to Celsius")]//Tells what the command do
        public async Task F_to_C(CommandContext CC, [Description("Unit")] float a)//Method to store command in a function. In this case 1 parameters are passed.
        {
            await CC.Channel
                .SendMessageAsync(a + " fahrenheit is equal to " + (a - 32) * 5 / 9 + " celsius.".ToString())//This converts fahrenheit and gives the result in celsius and convert it into string.
                .ConfigureAwait(false);
        }


        [Command("Convert-F-K")]//Command lets you name the command as you wish
        [Description("Converts Fahrenheit to Kelvin")]//Tells what the command do
        public async Task F_to_K(CommandContext CC, [Description("Unit")] float a)//Method to store command in a function. In this case 1 parameters are passed.
        {
            await CC.Channel
                .SendMessageAsync(a + " fahrenheit is equal to " + (a - 32) * 5 / 9 + 273.15 + " kelvin.".ToString())//This converts fahrenheit and gives the result in kelvin and convert it into string.
                .ConfigureAwait(false);
        }


        [Command("Convert-K-C")]//Command lets you name the command as you wish
        [Description("Converts Kelvins to Celsius")]//Tells what the command do
        public async Task K_to_C(CommandContext CC, [Description("Unit")] float a)//Method to store command in a function. In this case 1 parameters are passed.
        {
            await CC.Channel
                .SendMessageAsync(a + " kelvin is equal to " + (a - 273.15) + " celsius.".ToString())//This converts kelvin and gives the result in celsius and convert it into string.
                .ConfigureAwait(false);
        }


        [Command("Convert-K-F")]//Command lets you name the command as you wish
        [Description("Converts Kelvins to Fahrenheits")]//Tells what the command do
        public async Task K_to_F(CommandContext CC, [Description("Unit")] float a)//Method to store command in a function. In this case 1 parameters are passed.
        {
            await CC.Channel
                .SendMessageAsync(a + " kelvin is equal to " + ((a - 273.15) * 9 / 5 + 32) + " fahrenheits.".ToString())//This converts kelvin and gives the result in fahrenheits and convert it into string.
                .ConfigureAwait(false);
        }


        [Command("Disc")]//Command lets you roll 2 dices and the greater number wins. 
        [Description("roll two dices")]//Tells what the command do
        public async Task RollDice(CommandContext CC)
        {
           int deci1 = RandomNumber(1, 6);//Random Number Generator Function
           int deci2 = RandomNumber(1, 6);//Random Number Generator Function
            var Result = "a";
           //Condition to determine greater of two numbers
            if (deci1>deci2)
            {
                Result = "Player One Wins";
            }
           else if (deci2>deci1)
            {
                Result = "Player Two Wins";
            }
           else if (deci1==deci2)
            {
                Result = "Result is Draw";
            }
            await CC.Channel
            .SendMessageAsync((deci1, deci2).ToString());//This prints the outcome of rolled dice
            await CC.Channel
                .SendMessageAsync((Result).ToString())//This prints the result 
            .ConfigureAwait(false);
        }
    

        [Command("Coin")]//This command flips coin for toss
        [Description("flip a coin")]//Tells what the command do
        public async Task TossCoin(CommandContext CC)
        {
            int coinToss = RandomNumber(0,1);//Random Number Function
            string coinResult="a";
            //Condition to find outcome of toss
            switch(coinToss)
            {
                case 0:
                    coinResult = "HEADS";
                    break;
                case 1:
                    coinResult = "TAILS";
                        break;

            }
      
            await CC.Channel
            .SendMessageAsync((coinResult).ToString())//This is to print the outcome of the coin toss.
            .ConfigureAwait(false);


        }


        [Command("Joke")]//This command prints random jokes. 
        [Description("Tells You A Joke")]
        public async Task TellsJoke(CommandContext CC)
        {
            int no = RandomNumber(1, 21);//Random number generator function
            string joke="a1";
            //Switch stored jokes
            switch(no)
            {
                case 1: 
                    joke = "Why did Adele cross the road? To say hello from the other side.";
                    break;
            case 2:
                    joke = "What kind of concert only costs 45 cents? A 50 Cent concert featuring Nickelback.";
                    break;
                case 3:
                    joke = "What did the grape say when it got crushed? Nothing, it just let out a little wine.";
                        break;
                case 4:
                    joke = "I want to be cremated as it is my last hope for a smoking hot body.";
                        break;
                case 5:
                    joke = "Time flies like an arrow. Fruit flies like a banana.";
                        break;
                case 6:
                    joke = "To the guy who invented zero, thanks for nothing.";
                        break;
                case 7:
                    joke = "Geology rocks but Geography is where it’s at!";
                    break;
                case 8:
                    joke = "What was Forrest Gump’s email password? 1forrest1";
                    break;
                case 9:
                    joke = "Can February March? No, but April May";
                    break;
                case 10:
                    joke = "I don’t trust stairs because they’re always up to something.";
                    break;
                case 11:
                    joke = "What’s the best thing about Switzerland? I don’t know, but the flag is a big plus.";
                    break;
                case 12:
                    joke = "What did the left eye say to the right eye? Between you and me, something smells.";
                    break;
                case 13:
                    joke = "What do you call a fake noodle? An impasta.";
                    break;
                case 14:
                    joke = "What did the 0 say to the 8? Nice belt!";
                    break;
                case 15:
                    joke = "What did one hat say to the other? You wait here.I’ll go on a head.";
                    break;
                case 16:
                    joke = "What do you call a magic dog? A labracadabrador.";
                    break;
                case 17:
                    joke = "What did the shark say when he ate the clownfish? This tastes a little funny.";
                    break;
                case 18:
                    joke = "What did the pirate say when he turned 80? Aye matey.";
                    break;
                case 20:
                    joke = "Why did the frog take the bus to work today? His car got toad away.";
                    break;
                case 21:
                    joke = "Why did the yogurt go to the art exhibition? Because it was cultured.";
                    break;
                    

            }
            await CC.Channel
            .SendMessageAsync((joke).ToString())//Prints jokes
            .ConfigureAwait(false);
        }

        
        //Random Number Generator Function
        public int RandomNumber(int min, int max)
        {
             Random _random = new Random(); 
            return _random.Next(min, max);
        }
    }
}