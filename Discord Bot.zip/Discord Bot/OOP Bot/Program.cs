﻿
//First File of the code
namespace OOP_Bot//Project name
{
    class Program//Base Class of the bot
    {
        static void Main(string[] args)//C# way of Void or Int Main
        {
            var bot = new Bot();//Var variable lets compiler decide the variable data type during compilation. you dont have to declare data type during coding.
            //Bot() is the reference to another class Bot. which has its own file and enteries.
            //new lets you create another instance or rather newer instance of a defined data type.
            bot.RunAsync().GetAwaiter().GetResult();//Async lets the compiler run next command before completion of current running task.  GetAwaiter().GetResult() role is to propogate exceptoions in case an exception arise in a faulted code. 
        }
    }
}