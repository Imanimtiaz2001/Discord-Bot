﻿//Second Class File. Beginning file has a reference to this class. 

//Almost of these are added by the compiler itself to make sure respective commands work.
//Whem an unknown command is entered it searches in its directory and asks user to add certain file to allow compiler to use that command.
using System;                              
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using DSharpPlus;
using DSharpPlus.CommandsNext;
using DSharpPlus.EventArgs;
using OOP_Bot.Commands;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using DSharpPlus.Interactivity;
using DSharpPlus.Interactivity.Extensions;
using System.Threading;

namespace OOP_Bot//Name of the project
{
    public class Bot //Bot Class. Linked with Program Class.        
    {
        public DiscordClient Client { get; private set; }//Setters and Getters in C#. 
        public InteractivityExtension Interactivity { get; private set; }//Setter and Getter in C#. 
        public CommandsNextExtension Commands { get; private set; }//Setter and Getter in C#. 
        public async Task RunAsync() //Task run in Background and doesnot requires this task to be completed before beginning next task. 
        {
            var json = string.Empty;//JSON is a Java Script Notation. This is helpful in changing data type. This doesnot belong to any specific language. 
            //string.Empty initialize a null string. this can also be done using "". But .Empty saves memory. Thats why its preferred.          
            using (var fs = File.OpenRead("Config.json"))//File keyword locates a file in the same project. OpenRead lets the compiler to read data from the file mention in bracket. 
            using (var sr = new StreamReader(fs, new UTF8Encoding(false)))//StreamReader like the textreader reads data from the input stream. StreamReader can read data in a specified encoding unlike text reader.
            //UTF8Encoding is an encoding class like UTF16 and UTF32 Encorder. In  UTF8Encorder reads each point as a combination of bytes from 1-4.
                json = await sr.ReadToEndAsync().ConfigureAwait(false);//await is the keyword which can only be used in place where async is used. This lets the current task complete before moving onto next one.
            //ReadToEndAsync() is a defined function of C# which reads from the beginning to the end and compile it in one string.            
            //ConfigureAwait(false) is not necessary but a good C# programming practice. It performs no action but makes sure compiler doesnot move back to previous position.     
            var configJson = JsonConvert.DeserializeObject<Configuration>(json);//JsonConvert.DeserializeObject is a code converter. It converts a given code in JASON type in a .NET Code so it can be read and used in a .NET or C# program. 
            var config = new DiscordConfiguration //Already Built Class in DSharp Plus
            {
                Token= configJson.Token,//Token is a built-in variable in DiscordConfiguration class. Discord Bot App Token placed in Config.Json file under the name of Token.
                TokenType =TokenType.Bot,//TokenType is a built-in variable in DiscordConfiguration class. .Bot makes it a token of type Bot.
                AutoReconnect =true,//AutoReconnect in case of true makes the bot go online again incase it fails for some reason and is also a built-in variable of same class.
                MinimumLogLevel=LogLevel.Debug,//Sets log message access level
                //UseInternalLogHandler = true
            };

            Client = new DiscordClient(config);//Client keyword is for the user trying to access server.
            //DiscordClient is a built in class in C# packages.
            Client.Ready += OnClientReady;//This makes the bot go live on the server when the compiler runs.

            Client.UseInteractivity(new InteractivityConfiguration//Built-in Class. To set up different Interactivity functions like timeout and so on.
            {
                Timeout = TimeSpan.FromSeconds(5)//Timeout sets the time bot waits for the user to reply to a command. If the time period exceeds then the bot will not reply to the request.
             //Default timeout is set to 1 min but you can change using Timespan command. It uses .From Minutes, .ForMilliseconds, .For seconds and so on.
            });                                                                         


            var commandsConfig = new CommandsNextConfiguration //Alrerady defined public Class.             
            {
                StringPrefixes = new string[] { configJson.prefix },//String Prefix saves the determined prefix to use for any bot command. In this case its "?" and is stored in Config.Json file.
                EnableDms = true,//This allows bot to send direct message to user in case its true. This can be either true or false its up to you. 
                //In most cases it is set to false as it can cause some issues if some user have set dms allowed only from friends.
                EnableMentionPrefix = true,//This allows the mentioning of bot using the prefix. This should always be true otherwise no task can be performed.
                DmHelp = true,//This command allows bot to reply in dm if some user ask for help. The help message will give a list of functions this bot can perform.
                //In case someone mention certain commad after help it sends a description of that command.  
                EnableDefaultHelp = true,//Help draft is created by default in the C# libraries. In case of true it uses that draft and in case of false you can create your own help menu.
            };
            Commands = Client.UseCommandsNext(commandsConfig);//Using and taking commands from Client.
            Commands.RegisterCommands<Command1>();//Commands that bot will perform are in Commands folder having Command1 file.
            await Client.ConnectAsync();//Cinnects client to the server
            await Task.Delay(-1);//Running Bot for an indefinite period. Making sure bot doesnt go off.     
        }

        private Task OnClientReady(object sender, ReadyEventArgs a)//It handles event. In case if sender sends a command the bot return event a.

        {
            return Task.CompletedTask; 
        }
    }
}