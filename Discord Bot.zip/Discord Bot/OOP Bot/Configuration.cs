﻿using Newtonsoft.Json;
namespace OOP_Bot
{
    struct Configuration
    {
        [JsonProperty("Token")]//Stores the token in Json code. 
        public string Token { get; private set; }//Setter and getter function
        [JsonProperty("prefix")] //Stores the prefix in Json form    
        public string prefix { get; private set; }//Public Setter and getter function 
    }
}
